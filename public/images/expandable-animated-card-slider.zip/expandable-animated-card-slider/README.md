# Expandable Animated Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/reoundaunted/pen/KKbErrV](https://codepen.io/reoundaunted/pen/KKbErrV).

We have made an expandable animated card slider, it will expand and collapse based on card click. We used owl carousel and jQuery for variable width and responsive slider.